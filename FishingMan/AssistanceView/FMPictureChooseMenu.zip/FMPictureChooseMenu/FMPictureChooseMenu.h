//
//  FMPictureChooseMenu.h
//  FishingMan
//
//  Created by zxh on 2017/6/20.
//  Copyright © 2017年 HongFan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^PictureChooseMenuCallback) (BOOL show);

@interface FMPictureChooseMenu : UIView

@property (copy, nonatomic) PictureChooseMenuCallback callback;

+ (instancetype)shareWithTarget:(id)target
                                        callback:(PictureChooseMenuCallback) callback;
@end
