//
//  FMPictureChooseMenu.m
//  FishingMan
//
//  Created by zxh on 2017/6/20.
//  Copyright © 2017年 HongFan. All rights reserved.
//

#import "FMPictureChooseMenu.h"

@interface FMPictureChooseMenu ()
@property (weak, nonatomic) IBOutlet UIView *alphaBGView;

@end

@implementation FMPictureChooseMenu

-(void)awakeFromNib{
    [super awakeFromNib];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self addGestureRecognizer:tap];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(closeKeyboard)];
    [self addGestureRecognizer:pan];
}

+ (instancetype)shareWithTarget:(id)target callback:(PictureChooseMenuCallback) callback{
    
    FMPictureChooseMenu *chooseMenu = [[[NSBundle mainBundle] loadNibNamed:@"FMPictureChooseMenu" owner:self options:nil] firstObject];
    
    chooseMenu.callback = callback;
    chooseMenu.frame = CGRectMake(0, ZXHScreenHeight,
                                   ZXHScreenWidth, ZXHScreenHeight);
    
    /*** 背景高斯模糊 ***/
//    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
//    UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
//    effectView.frame = [[UIApplication sharedApplication] keyWindow].bounds;
//    [commentView.bgImageView addSubview:effectView];
    
    return chooseMenu;
}

- (void)show{
   
    self.frame = CGRectMake(0, ZXHScreenHeight, ZXHScreenWidth, ZXHScreenHeight);
    
}

- (void)dismiss{
}

- (void)closeKeyboard{
    [self removeFromSuperview];
}

@end
