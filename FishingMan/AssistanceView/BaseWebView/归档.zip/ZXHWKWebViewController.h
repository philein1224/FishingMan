//
//  ZXHWKWebViewController.h
//  FishingMan
//
//  Created by zhangxh on 2017/5/3.
//  Copyright © 2017年 HongFan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXHWKWebViewController : UIViewController

@property (strong, nonatomic) NSString  *urlString;

@end
